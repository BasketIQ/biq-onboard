"""Versioned, bounded diagnostic events; no implicit body or credential capture.

Services use OpenTelemetry for spans and call ``emit`` at domain boundaries.
The sink is injectable so tests never require Google credentials.
"""

from .events import DiagnosticContext, configure_json_logging, emit, operation, payload_shape

__all__ = ["DiagnosticContext", "configure_json_logging", "emit", "operation", "payload_shape"]
