"""Structured event contract shared by HTTP, jobs and infrastructure adapters."""

from __future__ import annotations

import contextlib
import contextvars
import datetime as dt
import json
import logging
import math
import os
import re
import sys
import time
import uuid
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, replace
from typing import Any, TextIO

LOGGER = logging.getLogger("biq.observability")
SCHEMA_VERSION = "1.0.0"
# Values, not just key names, must have an approved diagnostic meaning.
# Unknown keys are dropped, including nested payloads and arbitrary error messages.
NUMERIC = frozenset(
    {
        "duration_ms",
        "status_code",
        "attempt",
        "input_count",
        "output_count",
        "objective_count",
        "candidate_count",
        "discarded_count",
        "rows",
        "bytes",
        "queue_age_ms",
        "timeout_ms",
        "retry_delay_ms",
    }
)
LABELS = frozenset(
    {
        "operation",
        "dependency",
        "method",
        "route",
        "outcome",
        "error_type",
        "error_code",
        "reason",
        "store",
        "collection",
        "phase",
    }
)
_LABEL = re.compile(r"^[A-Za-z0-9_./:{} -]{1,160}$")
_ID = re.compile(r"^[a-f0-9]{32}$")


@dataclass(frozen=True)
class DiagnosticContext:
    """Request-local identity. Never use this context for authorization."""

    operation_id: str
    job_id: str | None = None
    attempt: int = 1


_CONTEXT: contextvars.ContextVar[DiagnosticContext | None] = contextvars.ContextVar(
    "biq_diagnostic_context", default=None
)


def _identifier(value: str | None) -> str | None:
    return value if value is not None and _ID.fullmatch(value) and int(value, 16) else None


def payload_shape(payload: Mapping[str, Any], fields: tuple[str, ...]) -> dict[str, Any]:
    """Describe presence/type/size only. Never stringify arbitrary input values.

    ``fields`` must be static schema field names supplied by the adapter, not
    keys copied from user input. Missing, null and an empty array stay distinct.
    """
    result: dict[str, Any] = {}
    for name in fields[:32]:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", name):
            continue
        if name not in payload:
            result[name] = {"state": "missing"}
            continue
        value = payload[name]
        if value is None:
            result[name] = {"state": "null"}
        elif isinstance(value, (list, tuple, dict, str)):
            result[name] = {"state": "present", "type": type(value).__name__, "count": len(value)}
        elif isinstance(value, (bool, int, float)):
            result[name] = {"state": "present", "type": type(value).__name__}
        else:
            result[name] = {"state": "unsupported"}
    return result


def _attributes(values: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in values.items():
        if key in NUMERIC and isinstance(value, (int, float)) and not isinstance(value, bool):
            if math.isfinite(value) and 0 <= value <= 1e15:
                result[key] = value
        elif key in LABELS and isinstance(value, str) and _LABEL.fullmatch(value):
            result[key] = value
    return result


def configure_json_logging(stream: TextIO | None = None) -> None:
    """Configure this dedicated logger only; leave application loggers untouched.

    Call once at service bootstrap. Repeated configuration replaces this logger's
    handler instead of multiplying events. The caller owns an injected stream.
    """
    handler = logging.StreamHandler(stream if stream is not None else sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    LOGGER.handlers = [handler]
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False


def emit(
    event: str,
    *,
    severity: str = "INFO",
    input_payload: Mapping[str, Any] | None = None,
    output_payload: Mapping[str, Any] | None = None,
    fields: tuple[str, ...] = (),
    **attributes: Any,
) -> dict[str, Any]:
    """Emit one JSON event and return it for adapters/tests.

    Free-form strings, request/response bodies, URLs, headers and exception
    messages are deliberately outside this API. Adapters use stable reason codes.
    Logging failures must never replace a business response.
    """
    if not re.fullmatch(r"[a-z][a-z0-9_.]{0,95}", event):
        raise ValueError("event must be a static diagnostic event name")
    row: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "event": event,
        "timestamp": dt.datetime.now(dt.UTC).isoformat(),
        "severity": severity if severity in {"DEBUG", "INFO", "WARNING", "ERROR"} else "INFO",
        "service": os.environ.get("K_SERVICE", "local"),
        "revision": os.environ.get("K_REVISION", "local"),
        "attributes": _attributes(attributes),
    }
    if input_payload is not None:
        row["input_shape"] = payload_shape(input_payload, fields)
    if output_payload is not None:
        row["output_shape"] = payload_shape(output_payload, fields)
    context = _CONTEXT.get()
    if context is not None:
        row.update(
            operation_id=context.operation_id, job_id=context.job_id, attempt=context.attempt
        )
    try:
        # Optional dependency: importing biq-core alone never configures a provider.
        from opentelemetry import trace

        span = trace.get_current_span().get_span_context()
        if span.is_valid:
            row["trace_id"] = format(span.trace_id, "032x")
            row["span_id"] = format(span.span_id, "016x")
            row["logging.googleapis.com/spanId"] = row["span_id"]
            row["logging.googleapis.com/trace_sampled"] = bool(span.trace_flags.sampled)
            project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("GCP_PROJECT")
            if project:
                row["logging.googleapis.com/trace"] = f"projects/{project}/traces/{row['trace_id']}"
    except ImportError:
        pass
    # A failed telemetry sink cannot fail a business operation.
    with contextlib.suppress(Exception):
        LOGGER.log(getattr(logging, row["severity"]), json.dumps(row, allow_nan=False))
    return row


@contextlib.contextmanager
def operation(
    name: str, *, operation_id: str | None = None, job_id: str | None = None, attempt: int = 1
) -> Iterator[DiagnosticContext]:
    """Maintain operation identity through nested work and reset on every exit.

    Across a queue persist the yielded operation_id alongside the work item;
    workers pass it back here. OTel context propagation is handled separately.
    """
    if not _LABEL.fullmatch(name) or attempt < 1:
        raise ValueError("invalid operation name or attempt")
    parent = _CONTEXT.get()
    context = DiagnosticContext(
        operation_id=_identifier(operation_id)
        or (parent.operation_id if parent else uuid.uuid4().hex),
        job_id=_identifier(job_id) or (parent.job_id if parent else None),
        attempt=attempt,
    )
    token = _CONTEXT.set(replace(context))
    started = time.perf_counter()
    try:
        emit("operation.started", operation=name)
        yield context
    except BaseException as exc:
        emit(
            "operation.finished",
            severity="ERROR",
            operation=name,
            outcome="error",
            error_type=type(exc).__name__,
            duration_ms=(time.perf_counter() - started) * 1000,
        )
        raise
    else:
        emit(
            "operation.finished",
            operation=name,
            outcome="success",
            duration_ms=(time.perf_counter() - started) * 1000,
        )
    finally:
        _CONTEXT.reset(token)
