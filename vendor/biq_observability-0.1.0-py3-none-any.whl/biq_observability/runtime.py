"""Staging ASGI + client instrumentation, exporting bounded spans to stdout.

No collector, credentials or additional infrastructure are required. Cloud Logging
stores span records; this exporter does NOT populate the Cloud Trace backend.
"""

from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import json
import os
import threading
import time
from collections.abc import Iterator, Mapping, Sequence
from typing import Any

from .events import _CONTEXT, LOGGER, configure_json_logging, emit, operation

_LOCK = threading.Lock()
_PROVIDER: Any = None
_SAFE_ATTRIBUTES = frozenset(
    {
        "http.method",
        "http.request.method",
        "http.status_code",
        "http.response.status_code",
        "http.route",
        "rpc.system",
        "rpc.service",
        "rpc.method",
        "db.system",
        "db.system.name",
        "db.operation",
        "db.operation.name",
        "error.type",
        "biq.operation_id",
        "biq.job_id",
        "biq.attempt",
    }
)


def _enabled() -> bool:
    setting = os.environ.get("BIQ_OBSERVABILITY_ENABLED")
    if setting is not None:
        return setting == "1"
    return os.environ.get("K_SERVICE", "").endswith("-staging")


def capture_context() -> dict[str, str]:
    """Persist this small carrier beside queued work; never persist baggage."""
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

    if not _enabled():
        return {}
    carrier: dict[str, str] = {}
    TraceContextTextMapPropagator().inject(carrier)
    current = _CONTEXT.get()
    if current:
        carrier["x-biq-operation-id"] = current.operation_id
    return {k: v for k, v in carrier.items() if k in {"traceparent", "x-biq-operation-id"}}


def _propagate_operation(headers: Any) -> None:
    current = _CONTEXT.get()
    if current:
        headers["x-biq-operation-id"] = current.operation_id


def configure_runtime() -> Any:
    """Install a single provider and supported client adapters per process."""
    global _PROVIDER
    with _LOCK:
        if _PROVIDER is not None:
            return _PROVIDER
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import (
            SimpleSpanProcessor,
            SpanExporter,
            SpanExportResult,
        )

        class JsonSpanExporter(SpanExporter):
            def export(self, spans: Sequence[Any]) -> SpanExportResult:
                for span in spans:
                    attributes = {
                        k: v
                        for k, v in (span.attributes or {}).items()
                        if k in _SAFE_ATTRIBUTES
                        and isinstance(v, (str, int, float, bool))
                        and len(str(v)) <= 256
                    }
                    row: dict[str, Any] = {
                        "schema_version": "1.0.0",
                        "event": "trace.span",
                        "severity": "ERROR" if span.status.status_code.name == "ERROR" else "INFO",
                        "service": os.environ.get("K_SERVICE", "local"),
                        "revision": os.environ.get("K_REVISION", "local"),
                        "trace_id": format(span.context.trace_id, "032x"),
                        "span_id": format(span.context.span_id, "016x"),
                        "parent_span_id": format(span.parent.span_id, "016x")
                        if span.parent
                        else None,
                        "span_kind": span.kind.name,
                        "status": span.status.status_code.name,
                        "start_time_unix_ns": span.start_time,
                        "duration_ms": (span.end_time - span.start_time) / 1_000_000,
                        "attributes": attributes,
                        "links": [
                            {
                                "trace_id": format(link.context.trace_id, "032x"),
                                "span_id": format(link.context.span_id, "016x"),
                            }
                            for link in span.links[:8]
                        ],
                    }
                    # Names, exception descriptions/events, URLs, SQL statements,
                    # resources and arbitrary SDK attributes are not exported.
                    row["logging.googleapis.com/spanId"] = row["span_id"]
                    row["logging.googleapis.com/trace_sampled"] = bool(
                        span.context.trace_flags.sampled
                    )
                    project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get(
                        "GCP_PROJECT"
                    )
                    if project:
                        row["logging.googleapis.com/trace"] = (
                            f"projects/{project}/traces/{row['trace_id']}"
                        )
                    with contextlib.suppress(Exception):
                        LOGGER.log(40 if row["severity"] == "ERROR" else 20, json.dumps(row))
                return SpanExportResult.SUCCESS

        class CorrelatedProcessor(SimpleSpanProcessor):
            def on_start(self, span: Any, parent_context: Any = None) -> None:
                current = _CONTEXT.get()
                if current:
                    span.set_attribute("biq.operation_id", current.operation_id)
                    span.set_attribute("biq.attempt", current.attempt)
                    if current.job_id:
                        span.set_attribute("biq.job_id", current.job_id)

        configure_json_logging()
        provider = TracerProvider(
            resource=Resource.create({"service.name": os.environ.get("K_SERVICE", "local")})
        )
        provider.add_span_processor(CorrelatedProcessor(JsonSpanExporter()))
        trace.set_tracer_provider(provider)
        if trace.get_tracer_provider() is not provider:
            provider.shutdown()
            raise RuntimeError("another OpenTelemetry provider is already configured")
        _PROVIDER = provider

        if importlib.util.find_spec("httpx") is not None:
            from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

            def request_hook(span: Any, request: Any) -> None:
                _propagate_operation(request.headers)

            async def async_request_hook(span: Any, request: Any) -> None:
                _propagate_operation(request.headers)

            HTTPXClientInstrumentor().instrument(
                request_hook=request_hook, async_request_hook=async_request_hook
            )
        if importlib.util.find_spec("requests") is not None:
            from opentelemetry.instrumentation.requests import RequestsInstrumentor

            def requests_hook(span: Any, request: Any) -> None:
                _propagate_operation(request.headers)

            RequestsInstrumentor().instrument(request_hook=requests_hook)
        if importlib.util.find_spec("grpc") is not None:
            from opentelemetry.instrumentation.grpc import (
                GrpcAioInstrumentorClient,
                GrpcInstrumentorClient,
            )

            GrpcInstrumentorClient().instrument()  # type: ignore[no-untyped-call]  # upstream constructor is untyped
            GrpcAioInstrumentorClient().instrument()  # type: ignore[no-untyped-call]  # upstream constructor is untyped
        if importlib.util.find_spec("psycopg") is not None:
            from opentelemetry.instrumentation.psycopg import PsycopgInstrumentor

            PsycopgInstrumentor().instrument()
        emit("service.instrumentation_ready")
        return provider


class DiagnosticMiddleware:
    """ASGI pass-through: no body reads, buffering or response replacement."""

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] == "lifespan":
            emit("service.starting")

            async def lifecycle_send(message: Any) -> None:
                events = {
                    "lifespan.startup.complete": "service.ready",
                    "lifespan.startup.failed": "service.startup_failed",
                    "lifespan.shutdown.complete": "service.stopped",
                    "lifespan.shutdown.failed": "service.shutdown_failed",
                }
                if message["type"] in events:
                    emit(
                        events[message["type"]],
                        severity="ERROR" if message["type"].endswith("failed") else "INFO",
                    )
                await send(message)

            async def lifecycle_receive() -> Any:
                message = await receive()
                if message["type"] == "lifespan.shutdown":
                    emit("service.stopping")
                return message

            await self.app(scope, lifecycle_receive, lifecycle_send)
            return
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        from opentelemetry import trace
        from opentelemetry.trace import SpanKind, Status, StatusCode
        from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

        # Accept only trace identity and diagnostic correlation, never arbitrary baggage.
        headers = {
            k.decode("latin1").lower(): v.decode("latin1")
            for k, v in scope.get("headers", [])
            if k.lower() in (b"traceparent", b"x-biq-operation-id")
        }
        context = TraceContextTextMapPropagator().extract(headers)
        status_code = 500
        response_bytes = 0
        started = time.perf_counter()
        with (
            operation("http.request", operation_id=headers.get("x-biq-operation-id")) as diagnostic,
            trace.get_tracer(__name__).start_as_current_span(
                "http.request",
                context=context,
                kind=SpanKind.SERVER,
                record_exception=False,
                set_status_on_exception=False,
            ) as span,
        ):

            async def observed_send(message: Any) -> None:
                nonlocal status_code, response_bytes
                if message["type"] == "http.response.start":
                    status_code = message["status"]
                    outgoing = [
                        (k, v)
                        for k, v in message.get("headers", [])
                        if k.lower() not in (b"x-biq-operation-id", b"x-biq-trace-id")
                    ]
                    outgoing.extend(
                        [
                            (b"x-biq-operation-id", diagnostic.operation_id.encode()),
                            (
                                b"x-biq-trace-id",
                                format(span.get_span_context().trace_id, "032x").encode(),
                            ),
                        ]
                    )
                    message = {**message, "headers": outgoing}
                elif message["type"] == "http.response.body":
                    response_bytes += len(message.get("body", b""))
                await send(message)

            try:
                await self.app(scope, receive, observed_send)
            except BaseException as exc:
                span.set_status(Status(StatusCode.ERROR))
                span.set_attribute("error.type", type(exc).__name__)
                raise
            finally:
                route = getattr(scope.get("route"), "path", "unmatched")
                method = scope.get("method", "UNKNOWN")
                span.set_attribute("http.route", route)
                span.set_attribute("http.request.method", method)
                span.set_attribute("http.response.status_code", status_code)
                if status_code >= 500:
                    span.set_status(Status(StatusCode.ERROR))
                emit(
                    "http.server.finished",
                    severity="ERROR" if status_code >= 500 else "INFO",
                    route=route,
                    method=method,
                    status_code=status_code,
                    bytes=response_bytes,
                    duration_ms=(time.perf_counter() - started) * 1000,
                )


def instrument_app(app: Any) -> Any:
    """Wire once, enabled by default only for *-staging Cloud Run services."""
    if not _enabled() or getattr(app.state, "biq_observability", False):
        return app
    configure_runtime()
    app.add_middleware(DiagnosticMiddleware)
    app.state.biq_observability = True
    return app


@contextlib.contextmanager
def job_operation(
    name: str, *, carrier: Mapping[str, str] | None = None, job_id: str, attempt: int = 1
) -> Iterator[Any]:
    """Start a worker trace linked to enqueue, retaining durable operation identity."""
    if not _enabled():
        yield None
        return
    configure_runtime()
    from opentelemetry import trace
    from opentelemetry.context import Context
    from opentelemetry.trace import Link, SpanKind
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

    carrier = carrier or {}
    source = trace.get_current_span(
        TraceContextTextMapPropagator().extract({"traceparent": carrier.get("traceparent", "")})
    ).get_span_context()
    links = [Link(source)] if source.is_valid else []
    safe_job_id = hashlib.sha256(job_id.encode()).hexdigest()[:32]
    with (
        operation(
            name,
            operation_id=carrier.get("x-biq-operation-id"),
            job_id=safe_job_id,
            attempt=max(1, attempt),
        ) as context,
        trace.get_tracer(__name__).start_as_current_span(
            name,
            context=Context(),
            links=links,
            kind=SpanKind.CONSUMER,
            record_exception=False,
            set_status_on_exception=False,
        ) as span,
    ):
        try:
            yield context
        except BaseException as exc:
            from opentelemetry.trace import Status, StatusCode

            span.set_status(Status(StatusCode.ERROR))
            span.set_attribute("error.type", type(exc).__name__)
            raise
